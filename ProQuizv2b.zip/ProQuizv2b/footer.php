<?php
/*!
 * **************************************************************
 ****************  ProQuiz V2.0.0b ******************************
 ***************************************************************/
 /* documentation at: http://proquiz.softon.org/documentation/
 /* Designed & Maintained by
 /*                                    - Softon Technologies
 /* Developer
 /*                                    - Manzovi
 /* For Support Contact @
 /*                                    - proquiz@softon.org
 /* version 2.0.0 beta (2 Feb 2011)
 /* Licensed under GPL license:
 /* http://www.gnu.org/licenses/gpl.html
 */
?><div class="corner-bLeft"></div>
	<div id="footer-valid">
		<span>&copy; All Rights Reserved <?php echo date('Y'); ?> | <a href="<?php echo SITE_LINK; ?>"><?php echo SITENAME; ?></a></span>
	</div>
    <div class="corner-bRight"></div>
</div>
<div id="softon"><?php print_copyright(); ?></div>
<?php clean_up(); ?>
