<?php
/*!
 * **************************************************************
 ****************  ProQuiz V2.0.0b ******************************
 ***************************************************************/
 /* documentation at: http://proquiz.softon.org/documentation/
 /* Designed & Maintained by
 /*                                    - Softon Technologies
 /* Developer
 /*                                    - Manzovi
 /* For Support Contact @
 /*                                    - proquiz@softon.org
 /* version 2.0.0 beta (2 Feb 2011)
 /* Licensed under GPL license:
 /* http://www.gnu.org/licenses/gpl.html
 */
?><div class="pq_ft"> 
    <div id="pq_next"  class="pq_btn">Next</div>
    <input id="pq_submit" style="border: none;" class="pq_btn" type="submit" value="Finish" />
    <div id="pqtimebtn" class="pq_btn">Time</div>
    <div id="pq_prev" class="pq_btn">Previous</div>
</div>