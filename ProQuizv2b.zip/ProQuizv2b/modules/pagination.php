<?php
/*!
 * **************************************************************
 ****************  ProQuiz V2.0.0b ******************************
 ***************************************************************/
 /* documentation at: http://proquiz.softon.org/documentation/
 /* Designed & Maintained by
 /*                                    - Softon Technologies
 /* Developer
 /*                                    - Manzovi
 /* For Support Contact @
 /*                                    - proquiz@softon.org
 /* version 2.0.0 beta (2 Feb 2011)
 /* Licensed under GPL license:
 /* http://www.gnu.org/licenses/gpl.html
 */
?>    <div class="paginationl"></div>
    <div class="paginationp"><a id="pagin_prev" href="#"></a></div>
    <div class="paginationpp"><a id="pagin_prev_sec" href="#"></a></div>
    <div class="paginationc">
        <ul>
            

        </ul>
    </div>
    <div class="paginationnn"><a id="pagin_next_sec" href="#"></a></div>
    <div class="paginationn"><a id="pagin_next" href="#"></a></div>
    <div class="paginationr"></div>
